import React from 'react';
function App() {
  return <h1>Welcome to Education Center</h1>;
}
export default App;